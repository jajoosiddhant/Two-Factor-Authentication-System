var searchData=
[
  ['send_5ffailcount',['send_failcount',['../timer_8h.html#a55e376dc85b536df9ec6900e587f8f63',1,'timer.h']]],
  ['sensor_5fcheck',['sensor_check',['../main_8h.html#a7576c244d44baaefabb65b7c96eaf2c9',1,'main.h']]]
];
