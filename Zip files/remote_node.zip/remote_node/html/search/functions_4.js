var searchData=
[
  ['delay_5fms',['delay_ms',['../delay_8h.html#ab7cce8122024d7ba47bf10f434956de4',1,'delay.h']]],
  ['delay_5fus',['delay_us',['../delay_8h.html#ab33ebb2c5ca2d80d259c64a9d658589f',1,'delay.h']]],
  ['disable_5ftimer',['disable_timer',['../timer_8c.html#a9a3c50abbb820b8264d89517258bdda1',1,'disable_timer(timer_t timer):&#160;timer.c'],['../timer_8h.html#a9a3c50abbb820b8264d89517258bdda1',1,'disable_timer(timer_t timer):&#160;timer.c']]]
];
