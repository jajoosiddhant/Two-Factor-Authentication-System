var searchData=
[
  ['otp_5farr',['otp_arr',['../main_8h.html#ab5bbd30029e626af8b4182b43bd62e15',1,'main.h']]],
  ['otp_5fcount',['otp_count',['../main_8h.html#ada8361483dd5ab067abcf88162b07b65',1,'main.h']]],
  ['otp_5fflag',['otp_flag',['../main_8h.html#a2b4e3bab201a01e073d7547c75f2c818',1,'main.h']]],
  ['otp_5finput_5ftime',['OTP_INPUT_TIME',['../timer_8h.html#a2d0471dc86c6fdf8f888f34326d199b6',1,'timer.h']]],
  ['otp_5fretries',['otp_retries',['../main_8h.html#a7684c13abe3891fb7d1dae867803feab',1,'main.h']]],
  ['otp_5fsend_5fbbg_5fid',['OTP_SEND_BBG_ID',['../main_8h.html#a03eb64e18a3335a85856fa179461bfb0',1,'main.h']]],
  ['otp_5fsent_5fuser_5fid',['OTP_SENT_USER_ID',['../main_8h.html#abe8df89752561e21facf04bcec072872',1,'main.h']]]
];
