var searchData=
[
  ['mutex_5fcreate',['mutex_create',['../sync__objects_8c.html#afb95a6886b67a64eccb27294bdfd5eeb',1,'mutex_create(void):&#160;sync_objects.c'],['../sync__objects_8h.html#afb95a6886b67a64eccb27294bdfd5eeb',1,'mutex_create(void):&#160;sync_objects.c']]]
];
