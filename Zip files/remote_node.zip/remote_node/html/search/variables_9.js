var searchData=
[
  ['tx_5fpipe_5faddress',['tx_pipe_address',['../struct_t_x.html#a53fe562ca0ad738c27ac2cbc19c77513',1,'TX']]]
];
