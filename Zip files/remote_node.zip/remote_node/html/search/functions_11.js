var searchData=
[
  ['uart_5fbbg_5ftest',['uart_bbg_test',['../uart__comm__bbg_8c.html#aee4827e75b9bf6e2c3e30da1abf96eba',1,'uart_bbg_test(void):&#160;uart_comm_bbg.c'],['../uart__comm__bbg_8h.html#aee4827e75b9bf6e2c3e30da1abf96eba',1,'uart_bbg_test(void):&#160;uart_comm_bbg.c']]],
  ['uart_5fbusy',['uart_busy',['../myuart_8h.html#a5e1fb6f1ff3e974df6dc6b6a7b9127cd',1,'myuart.h']]],
  ['uart_5fcomm_5fflushrx',['uart_comm_flushRX',['../myuart_8c.html#aa85d4eb8bdd6cf94b69156d68a689e63',1,'uart_comm_flushRX(uart_t uart):&#160;myuart.c'],['../myuart_8h.html#aa85d4eb8bdd6cf94b69156d68a689e63',1,'uart_comm_flushRX(uart_t uart):&#160;myuart.c']]],
  ['uart_5fcomm_5fflushtx',['uart_comm_flushTX',['../myuart_8c.html#ac22afb7956589bf2c7e91014aa075ef0',1,'uart_comm_flushTX(uart_t uart):&#160;myuart.c'],['../myuart_8h.html#ac22afb7956589bf2c7e91014aa075ef0',1,'uart_comm_flushTX(uart_t uart):&#160;myuart.c']]],
  ['uart_5fcommhandler',['uart_commhandler',['../uart__comm__bbg_8c.html#a007b15f62c7cddbebcdf95b9b6509045',1,'uart_commhandler(void):&#160;uart_comm_bbg.c'],['../uart__comm__bbg_8h.html#a007b15f62c7cddbebcdf95b9b6509045',1,'uart_commhandler(void):&#160;uart_comm_bbg.c']]],
  ['uart_5fconfigure',['uart_configure',['../myuart_8c.html#a039ece338f7cef5fa0656613789d48df',1,'uart_configure(uart_t uart, uint32_t clock, uint32_t baudrate, bool irq):&#160;myuart.c'],['../myuart_8h.html#a039ece338f7cef5fa0656613789d48df',1,'uart_configure(uart_t uart, uint32_t clock, uint32_t baudrate, bool irq):&#160;myuart.c']]],
  ['uart_5fpacket_5fhandler',['uart_packet_handler',['../uart__comm__bbg_8c.html#af2ba56c50ecfd4c67c3ed7cea1c90914',1,'uart_packet_handler(packet datap_rcv):&#160;uart_comm_bbg.c'],['../uart__comm__bbg_8h.html#af2ba56c50ecfd4c67c3ed7cea1c90914',1,'uart_packet_handler(packet datap_rcv):&#160;uart_comm_bbg.c']]],
  ['uart_5fsend',['uart_send',['../myuart_8c.html#a790c4518a60e75109b5b6550cac3befb',1,'uart_send(uart_t uart, uint8_t value):&#160;myuart.c'],['../myuart_8h.html#a790c4518a60e75109b5b6550cac3befb',1,'uart_send(uart_t uart, uint8_t value):&#160;myuart.c']]]
];
