var searchData=
[
  ['queue_5fcreate',['queue_create',['../msg__queue_8c.html#a553f3c27dec1d717b06f29199744ffc7',1,'queue_create(void):&#160;msg_queue.c'],['../msg__queue_8h.html#a553f3c27dec1d717b06f29199744ffc7',1,'queue_create(void):&#160;msg_queue.c']]]
];
