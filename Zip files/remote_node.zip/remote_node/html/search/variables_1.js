var searchData=
[
  ['degrade_5fmode',['degrade_mode',['../main_8h.html#a3fb60131d9638b88363ff2440a3475c3',1,'main.h']]]
];
