var searchData=
[
  ['reset_5fsystem',['reset_system',['../uart__comm__bbg_8c.html#af4f7d0cc01f643dd07c8bd8a9af799f6',1,'reset_system(void):&#160;uart_comm_bbg.c'],['../uart__comm__bbg_8h.html#af4f7d0cc01f643dd07c8bd8a9af799f6',1,'reset_system(void):&#160;uart_comm_bbg.c']]],
  ['reset_5ftimer',['reset_timer',['../timer_8c.html#a7a48b799a011e757e09e2b045e08324e',1,'reset_timer(timer_t timer, uint32_t ms):&#160;timer.c'],['../timer_8h.html#a7a48b799a011e757e09e2b045e08324e',1,'reset_timer(timer_t timer, uint32_t ms):&#160;timer.c']]]
];
