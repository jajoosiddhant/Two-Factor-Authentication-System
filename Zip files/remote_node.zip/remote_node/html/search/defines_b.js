var searchData=
[
  ['otp_5finput_5ftime',['OTP_INPUT_TIME',['../timer_8h.html#a2d0471dc86c6fdf8f888f34326d199b6',1,'timer.h']]],
  ['otp_5fsend_5fbbg_5fid',['OTP_SEND_BBG_ID',['../main_8h.html#a03eb64e18a3335a85856fa179461bfb0',1,'main.h']]],
  ['otp_5fsent_5fuser_5fid',['OTP_SENT_USER_ID',['../main_8h.html#abe8df89752561e21facf04bcec072872',1,'main.h']]]
];
