var searchData=
[
  ['enable_5ftimer_5fint',['enable_timer_int',['../timer_8c.html#aeac25b893d3d7db83d6e9aa8b776fb78',1,'enable_timer_int(timer_t timer):&#160;timer.c'],['../timer_8h.html#aeac25b893d3d7db83d6e9aa8b776fb78',1,'enable_timer_int(timer_t timer):&#160;timer.c']]]
];
