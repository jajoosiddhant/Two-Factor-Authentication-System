var searchData=
[
  ['spi0',['SPI0',['../spi_8h.html#a4c4c3893bd4169998937dd7199875d64a7add1e0588a075d9385b10fcbb2010f4',1,'spi.h']]],
  ['spi1',['SPI1',['../spi_8h.html#a4c4c3893bd4169998937dd7199875d64add83ddb396fbcb33f2d61248e5c4a185',1,'spi.h']]],
  ['spi2',['SPI2',['../spi_8h.html#a4c4c3893bd4169998937dd7199875d64a382fe69d09c301ce8af3660713dfe8a2',1,'spi.h']]]
];
