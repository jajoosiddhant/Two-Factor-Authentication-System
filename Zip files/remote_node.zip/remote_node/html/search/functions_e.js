var searchData=
[
  ['sem_5fcreate',['sem_create',['../sync__objects_8c.html#a16242c93769e5c5b88cc48c39a635d5a',1,'sem_create(void):&#160;sync_objects.c'],['../sync__objects_8h.html#a16242c93769e5c5b88cc48c39a635d5a',1,'sem_create(void):&#160;sync_objects.c']]],
  ['sensorcheck',['sensorcheck',['../application_8c.html#afd1ae504eb20b36a8e920441746c0822',1,'sensorcheck(void *pvParameters):&#160;application.c'],['../application_8h.html#afd1ae504eb20b36a8e920441746c0822',1,'sensorcheck(void *pvParameters):&#160;application.h']]],
  ['sensortask_5finit',['sensortask_init',['../application_8c.html#a660b9749ff9add1e4e6934b2eea58e64',1,'sensortask_init(void):&#160;application.c'],['../application_8h.html#a660b9749ff9add1e4e6934b2eea58e64',1,'sensortask_init(void):&#160;application.c']]],
  ['spi_5fbusy',['spi_busy',['../spi_8c.html#a410917834e60f39dd58213a9db49937a',1,'spi_busy(spi_t spi):&#160;spi.c'],['../spi_8h.html#a410917834e60f39dd58213a9db49937a',1,'spi_busy(spi_t spi):&#160;spi.c']]],
  ['spi_5fconfig',['spi_config',['../spi_8c.html#a7dbbafb70cebe270ca4f8494c17d958d',1,'spi_config(spi_t ssi_x):&#160;spi.c'],['../spi_8h.html#a7dbbafb70cebe270ca4f8494c17d958d',1,'spi_config(spi_t ssi_x):&#160;spi.c']]],
  ['spi_5fdummy_5ftransfer',['spi_dummy_transfer',['../spi_8c.html#a33d0c312bb3d752f8e48abba2eedddab',1,'spi_dummy_transfer(spi_t spi):&#160;spi.c'],['../spi_8h.html#a33d0c312bb3d752f8e48abba2eedddab',1,'spi_dummy_transfer(spi_t spi):&#160;spi.c']]],
  ['spi_5ftransfer',['spi_transfer',['../spi_8c.html#a405efb20abca5d728ba32aba56723102',1,'spi_transfer(spi_t spi, uint8_t value):&#160;spi.c'],['../spi_8h.html#a405efb20abca5d728ba32aba56723102',1,'spi_transfer(spi_t spi, uint8_t value):&#160;spi.c']]],
  ['system_5finit',['system_init',['../application_8c.html#a43f5e0d6db0fb41a437cc9096b32e9b5',1,'system_init(void):&#160;application.c'],['../application_8h.html#a43f5e0d6db0fb41a437cc9096b32e9b5',1,'system_init(void):&#160;application.c']]]
];
