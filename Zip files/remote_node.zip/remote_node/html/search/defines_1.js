var searchData=
[
  ['baudrate_5fbbg',['BAUDRATE_BBG',['../uart__comm__bbg_8h.html#a91d2287d55c6cb78d48c853ac69870af',1,'uart_comm_bbg.h']]],
  ['baudrate_5ffp',['BAUDRATE_FP',['../myuart_8h.html#afb6e3b62acce6882ca209d4ad5b3f5b3',1,'myuart.h']]],
  ['buzzer_5fpin',['BUZZER_PIN',['../buzzer_8h.html#ab61d0981ed42df9e18211b273d22cfcd',1,'buzzer.h']]],
  ['buzzer_5fport',['BUZZER_PORT',['../buzzer_8h.html#abf0d28f731e836936a87086ea8b798da',1,'buzzer.h']]]
];
