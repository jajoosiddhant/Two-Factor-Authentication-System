var searchData=
[
  ['mode_5frx',['mode_rx',['../nrf__driver_8h.html#a8eed5a50145baadb7eb8bf497dbb06e3ae088a96e38e478d73656eb4dee959e64',1,'nrf_driver.h']]],
  ['mode_5ftx',['mode_tx',['../nrf__driver_8h.html#a8eed5a50145baadb7eb8bf497dbb06e3afe2af8623ba4be84ceb3458b8d63aade',1,'nrf_driver.h']]]
];
