var searchData=
[
  ['secret_5fpasscode_5fid',['SECRET_PASSCODE_ID',['../main_8h.html#a3137f6b92db4e565e894b28efe314578',1,'main.h']]],
  ['set_5f4_5fbit',['SET_4_BIT',['../lcd_8h.html#afd805d95d1d0cc37ba9789f1c1f99d93',1,'lcd.h']]],
  ['shift',['SHIFT',['../nrf__driver_8h.html#a86eb8dcfca5e7faa37cd8d4bb2c7d797',1,'nrf_driver.h']]],
  ['start_5fcode1',['START_CODE1',['../fingerprint_8h.html#a168e9f15badd23f82af4bf8f820d6452',1,'fingerprint.h']]],
  ['start_5fcode2',['START_CODE2',['../fingerprint_8h.html#ab49143e1ba9f4208313c5493d4da11b0',1,'fingerprint.h']]]
];
