var searchData=
[
  ['modes_5ft',['modes_t',['../nrf__driver_8h.html#a8eed5a50145baadb7eb8bf497dbb06e3',1,'nrf_driver.h']]]
];
