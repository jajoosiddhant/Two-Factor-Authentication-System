var searchData=
[
  ['g_5fled',['g_led',['../sync__objects_8h.html#a15ff766ded960691eeba8e72c31b8bb1',1,'sync_objects.h']]],
  ['g_5fqsem',['g_qsem',['../sync__objects_8h.html#ab70ea115a56f3030cbe8e18e81ce10ed',1,'sync_objects.h']]],
  ['g_5ftemp',['g_temp',['../sync__objects_8h.html#a6beba4fd52ab4450ace824d80f7d302a',1,'sync_objects.h']]],
  ['g_5fuartsem',['g_uartsem',['../sync__objects_8h.html#af5a6ac6fa4e436448795f7f65a26069a',1,'sync_objects.h']]],
  ['g_5fui32sysclock',['g_ui32SysClock',['../main_8h.html#a85ea8ca26e195a17da88e70e7e4ddf82',1,'main.h']]]
];
