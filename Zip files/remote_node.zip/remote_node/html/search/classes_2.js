var searchData=
[
  ['temp',['temp',['../structtemp.html',1,'']]],
  ['tx',['TX',['../struct_t_x.html',1,'']]]
];
