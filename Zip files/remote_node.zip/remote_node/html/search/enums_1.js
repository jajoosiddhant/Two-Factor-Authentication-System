var searchData=
[
  ['spi_5ft',['spi_t',['../spi_8h.html#a4c4c3893bd4169998937dd7199875d64',1,'spi.h']]]
];
